Im�genes tomadas de:

https://www.ford.com/cars/taurus/2016/
http://www.motortrend.com/cars/chevrolet/camaro/2016/2016-chevrolet-camaro-rs-v-6-first-test-review/
https://www.coxchevy.com/2017-chevy-colorado-reviews/
http://thenewswheel.com/two-new-hues-of-2016-corvette-stingray-revealed/
http://www.motortrendenespanol.com/noticias/chevrolet-silverado-2500hd-4wd-z71-ltz-2017-primera-prueba/
http://www.peugeot.es/gama/selector-de-coches/peugeot-208-5-puertas.html
http://www.caranddriver.com/mazda/mazda-6